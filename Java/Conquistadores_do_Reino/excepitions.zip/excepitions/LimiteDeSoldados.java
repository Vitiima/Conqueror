package excepitions;

public class LimiteDeSoldados {

}
