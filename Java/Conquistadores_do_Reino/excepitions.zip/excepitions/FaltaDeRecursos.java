package excepitions;

public class FaltaDeRecursos extends RuntimeException {

	public FaltaDeRecursos(String mensage) {
		super(mensage);
	}

}
