package excepitions;

public class Derrota {

}
